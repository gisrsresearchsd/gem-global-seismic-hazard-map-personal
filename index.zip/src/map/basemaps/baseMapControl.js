import L from 'leaflet';
import { BASE_MAPS } from './baseMaps';

let currentBaseLayer = BASE_MAPS.Light;

export function createBaseMapControl(
  map,
  activeOverlayLayers = []
) {

  // Ensure default layer reference
  currentBaseLayer.addTo(map);

  const baseMapControl = L.control({
    position: 'topright',
  });

  baseMapControl.onAdd = function () {

    const container = L.DomUtil.create(
      'div',
      'custom-basemap-control'
    );

    L.DomEvent.disableClickPropagation(container);

    Object.keys(BASE_MAPS).forEach(
      (baseMapName) => {

        const button = L.DomUtil.create(
          'button',
          'basemap-btn',
          container
        );

        button.innerHTML = baseMapName;

        if (baseMapName === 'Light') {
          button.classList.add('active');
        }

        button.addEventListener('click', () => {

          // Remove current basemap safely
          if (currentBaseLayer) {
            map.removeLayer(currentBaseLayer);
          }

          // Set new basemap
          currentBaseLayer =
            BASE_MAPS[baseMapName];

          // Add new basemap
          currentBaseLayer.addTo(map);

          // Re-add overlays
          activeOverlayLayers.forEach((layer) => {

            if (!map.hasLayer(layer)) {
              layer.addTo(map);
            }

            if (layer.bringToFront) {
              layer.bringToFront();
            }
          });

          // Active button state
          container
            .querySelectorAll('.basemap-btn')
            .forEach((btn) => {
              btn.classList.remove('active');
            });

          button.classList.add('active');
        });
      }
    );

    return container;
  };

  baseMapControl.addTo(map);
}